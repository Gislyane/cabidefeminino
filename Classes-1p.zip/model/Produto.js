class Produto{
  constructor(tipo, cor, tamanho, fornecedor, codigo){
    this.tipo = tipo;
    this.cor = cor;
    this.tamanho = tamanho;
    this.fornecedor = fornecedor;
    this.codigo = codigo
  }
}
module.exports = Produto;
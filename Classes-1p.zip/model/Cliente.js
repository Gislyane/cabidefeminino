class Cliente{
  constructor(nome, cpf, endereco, telefone){
this.nome = nome;
this.cpf = cpf;
this.endereco = endereco;
this.telefone = telefone
  }
}

module.exports = Cliente;
class Entrega{
  constructor(cliente, endereco, numero, telefone, cidade, codigo, pagamento){
this.cliente = cliente;
this.endereco = endereco;
this.numero = numero
this.telefone = telefone
this.cidade = cidade;
this.codigo = codigo;
this.pagamento = pagamento
  }
}

module.exports = Entrega;
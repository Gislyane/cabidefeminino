class Funcionario{
  constructor(nome, salario){
this.nome = nome;
this.salario = salario; 
  }
}

module.exports = Funcionario;